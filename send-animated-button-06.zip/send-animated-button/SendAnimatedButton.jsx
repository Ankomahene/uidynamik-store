import React from 'react';
import './SendAnimatedButton.css';
import SendIcon from './SendIcon';

export const SendAnimatedButton = () => {
	return (
		<button>
			<div className="icon-wrapper">
				<SendIcon />
			</div>
			<div className="button-text">Send</div>
		</button>
	);
};
