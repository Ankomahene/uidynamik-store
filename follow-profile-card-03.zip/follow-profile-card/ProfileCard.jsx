import './ProfileCard.css';

const ProfileCard = ({ name, description, coverImage, profileImage }) => {
	return (
		<div className="Card">
			<div className="cover-image-wrapper">
				<img className="cover-image" src={`./images/${coverImage}`} alt="" width="100%" />
			</div>
			<div className="profile-photo-wrapper">
				<img src={`./images/${profileImage}`} alt="" width="100%" />
			</div>

			<div className="about">
				<div className="name">{name}</div>
				<div className="description"> {description}</div>
			</div>
			<button className="follow-btn">Follow</button>
		</div>
	);
};

ProfileCard.defaultProps = {
	name: 'Sarah Doe',
	description: 'Full time Associate Software Engineer at ABC Company',
	coverImage: 'cover.jpg', //replace with cover image
	profileImage: 'profile.jpg' //replace with profile image
};

export default ProfileCard;
