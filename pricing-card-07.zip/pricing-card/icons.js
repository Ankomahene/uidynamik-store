import React from 'react';

export const CheckIcon = () => (
	<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="#00ff00" viewBox="0 0 20 20">
		<title>checkmark</title>
		<path d="M0 11l2-2 5 5 11-11 2 2-13 13z" />
	</svg>
);

export const Logo = () => (
	<svg id="logo-35" width="50" height="39" viewBox="0 0 50 39" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path d="M16.4992 2H37.5808L22.0816 24.9729H1L16.4992 2Z" fill="#cd004d" />
		<path d="M17.4224 27.102L11.4192 36H33.5008L49 13.0271H32.7024L23.2064 27.102H17.4224Z" fill="#ec087a" />
	</svg>
);
