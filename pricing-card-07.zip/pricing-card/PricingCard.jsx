import React from 'react';
import './PricingCard.css';
import { CheckIcon, Logo } from './icons';

const PricingCard = ({ cardOptions: { title, price, offers }, handleButtonClick }) => {
	return (
		<div className="card">
			<div className="card-logo-wrapper">
				<Logo />
			</div>
			<h4 className="card-title">{title}</h4>
			<div className="card-price-wrapper">
				<div className="card-amount">{price}</div>
				<div className="card-duration">PER MONTH</div>
			</div>
			<div className="card-offers">
				{offers.map(offer => {
					return (
						<div className="single-offer" key={offer}>
							<div className="offer-icon-wrapper">
								<CheckIcon />
							</div>
							<div>{offer}</div>
						</div>
					);
				})}
			</div>
			<div className="card-button-wrapper">
				<button onClick={handleButtonClick}>START</button>
			</div>
		</div>
	);
};

PricingCard.defaultProps = {
	cardOptions: {
		title: 'Starter',
		price: '$9.99',
		offers: [
			'Unlimited repositories (Public/Private)',
			'Unlimited collaborators',
			'5GB storage space',
			'1 Year Community Support'
		]
	}
};

export default PricingCard;
