import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlidingLoginSignupComponent } from './sliding-login-signup.component';

describe('SlidingLoginSignupComponent', () => {
  let component: SlidingLoginSignupComponent;
  let fixture: ComponentFixture<SlidingLoginSignupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SlidingLoginSignupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SlidingLoginSignupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
