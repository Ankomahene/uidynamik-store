import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-sliding-login-signup',
	templateUrl: './sliding-login-signup.component.html',
	styleUrls: ['./sliding-login-signup.component.scss']
})
export class SlidingLoginSignupComponent {
	isRightPanelActive = false;

	toggleRightPanel(): void {
		this.isRightPanelActive = !this.isRightPanelActive;
	}
}
