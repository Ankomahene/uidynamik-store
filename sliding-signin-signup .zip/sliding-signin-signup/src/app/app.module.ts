import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SlidingLoginSignupComponent } from './components/sliding-login-signup/sliding-login-signup.component';

@NgModule({
  declarations: [
    AppComponent,
    SlidingLoginSignupComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
