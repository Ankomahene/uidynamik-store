import ProfileCard from './components/ProfileCard';
import './App.css';

function App() {
	return (
		<div className="App">
			<ProfileCard />
			<ProfileCard
				name="John Doe"
				about="Senior Graphic Designer at Best point"
				cover="cover-2.jpg"
				profile="profile-1.jpg"
			/>
		</div>
	);
}

export default App;
