import './ProfileCard.css';

// When a PROP(name, about, cover, profile) is not passed, it used default value;
const ProfileCard = ({ name, about, cover, profile }) => {
	return (
		<div className="Card">
			<div className="profile">
				<img className="cover-photo" src={`./images/${cover || 'cover-1.jpg'}`} alt="cover" width="100%" />
				<div className="profile-photo-wrapper">
					<div className="profile-photo">
						<img src={`./images/${profile || 'profile-1.jpg'}`} alt="profile" width="100%" />
					</div>
				</div>
			</div>

			<div className="content">
				<div className="name">{name || 'Mister Shadrack'}</div>
				<div className="about"> {about || 'Full time Associate Software Engineer @Faithtower Media-teck'}</div>
			</div>
			<button className="follow-btn">Follow</button>
		</div>
	);
};

export default ProfileCard;
