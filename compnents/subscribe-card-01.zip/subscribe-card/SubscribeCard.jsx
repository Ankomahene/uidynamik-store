import React from 'react';
import './SubscribeCard.css';
import Icon from './Icon';

export const SubscribeCard = () => {
	const handleSubscription = () => {
		// action here
	};

	return (
		<div className="subscribe-card">
			<div className="icon-wrapper">
				<Icon />
			</div>
			<div className="title">
				<h4>Get the latest updates right into your inbox!</h4>
			</div>
			<p className="description">Join 6k+ subscribers!</p>
			<div className="form">
				<input type="email" name="" id="" placeholder="Enter your email" />
				<button onClick={handleSubscription}>Subscribe</button>
			</div>
		</div>
	);
};
