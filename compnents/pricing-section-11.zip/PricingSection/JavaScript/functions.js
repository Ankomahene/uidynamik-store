export const getPricingCardOptions = cardDuration => {
	const generalOptions = {
		currencySymbol: '$',
		durationLabel: cardDuration === 'annual' ? 'yr' : 'mon'
	};

	const commonOffers = [ 'Integration help', 'Sketch Files', 'API Access', 'Complete documentation' ];

	return {
		starter: {
			...generalOptions,
			levelName: 'starter',
			amount: cardDuration === 'annual' ? 299 : 59,
			offers: [ '2 team members', '20GB Cloud storage', ...commonOffers ]
		},
		premium: {
			...generalOptions,
			levelName: 'premium',
			amount: cardDuration === 'annual' ? 599 : 89,
			offers: [ '10 team members', '40GB Cloud storage', ...commonOffers ]
		},
		enterprise: {
			...generalOptions,
			levelName: 'enterprise',
			amount: cardDuration === 'annual' ? 999 : 399,
			offers: [ 'Unlimited team members', '100GB Cloud storage', ...commonOffers ]
		}
	};
};

export const getTabStyle = (cardDuration, duration) =>
	cardDuration === duration ? { backgroundColor: '#4b65fb', color: '#fff', boxShadow: '1px 1px 3px gray' } : {};
