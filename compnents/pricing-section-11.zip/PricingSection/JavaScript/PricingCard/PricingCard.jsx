import React from 'react';
import { IPricingCardOptions } from '../Typescript/models';
// import './PricingCard.css';

export const PricingCard = ({ options }) => {
	const { levelName, currencySymbol, durationLabel, amount, offers } = options;

	return (
		<div className="pricing-card">
			<div className="level-tag-box">
				<span>{levelName}</span>
			</div>
			<div className="price-box">
				<span className="currency">{currencySymbol}</span>
				<span className="amount">{amount}</span>
				<span className="duration">/{durationLabel}</span>
			</div>
			<div className="offers-box">
				<div>
					{offers.map((offer, index) => (
						<div key={index} className="offer">
							{offer}
						</div>
					))}
				</div>
			</div>
			<div className="action-box">
				<button className="btn">
					join <span className="arrow-icon" />
				</button>
			</div>
		</div>
	);
};
