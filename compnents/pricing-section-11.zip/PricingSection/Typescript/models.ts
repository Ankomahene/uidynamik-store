export type Duration = 'monthly' | 'annual';

export interface IPricingCardOptions {
	levelName: string;
	currencySymbol: string;
	durationLabel: string;
	amount: number;
	offers: string[];
}
