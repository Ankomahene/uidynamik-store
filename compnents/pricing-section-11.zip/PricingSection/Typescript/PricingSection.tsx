import React, { Fragment, useState } from 'react';
import { getPricingCardOptions, getTabStyle } from './functions';
import { Duration } from './models';
import { PricingCard } from './PricingCard/PricingCard';
// import './PricingSection.css';

export const PricingSection = () => {
	const [ duration, setDuration ] = useState<Duration>('monthly');

	return (
		<Fragment>
			<div className="banner">
				<h1 className="banner-heading">See Our Pricing</h1>
				<p className="banner-description">
					You have Free Unlimited Updates and Premium Support on each package
				</p>
				<div className="duration-tabs">
					<button
						onClick={() => setDuration('monthly')}
						className="tab"
						style={getTabStyle('monthly', duration)}
					>
						Monthly
					</button>
					<button
						onClick={() => setDuration('annual')}
						className="tab"
						style={getTabStyle('annual', duration)}
					>
						Annual
					</button>
				</div>
			</div>
			<div className="pricing-cards">
				<PricingCard options={getPricingCardOptions(duration).starter} />
				<PricingCard options={getPricingCardOptions(duration).premium} />
				<PricingCard options={getPricingCardOptions(duration).enterprise} />
			</div>
		</Fragment>
	);
};
