import React, { Fragment } from 'react';
import './NewsLetterSignUpForm.css';

export const NewsletterSignUpForm = () => {
	return (
		<Fragment>
			<div className="newsletter-sign-up-form-wrapper">
				<h3 className="form-title">Enjoyed this read?</h3>
				<p className="form-description">
					Stay up to date with the latest video business news, strategies, and insights sent straight to your
					inbox!
				</p>
				<form
					name="newsletter-sign-up-form"
					data-name="Newsletter Sign Up Form"
					className="newsletter-sign-up-form"
					aria-label="Newsletter Sign Up Form"
				>
					<input
						type="email"
						className="email-input-field"
						maxLength={256}
						name="email-input-field"
						data-name="Email Address"
						placeholder="Email address"
						required
					/>
					<input type="submit" value="Subscribe" className="newsletter-submit-button" />
				</form>
			</div>
		</Fragment>
	);
};
