import React, { ChangeEvent, Dispatch, DragEventHandler, useRef, useState } from 'react';
import './DropZone.css';

interface IDropZoneProps {
	setFiles: Dispatch<React.SetStateAction<File[]>>; //dispatch state handler to add dropped files to state in parent
}

export const DropZone = ({ setFiles }: IDropZoneProps) => {
	const [ isDragging, setIsDragging ] = useState(false);
	const fileInput = useRef<HTMLInputElement>(null); //be sure to cleanup your ref after uploading by resetting the current value

	const dragOver: DragEventHandler<HTMLDivElement> = e => {
		e.preventDefault();
		setIsDragging(true);
	};

	const dragEnter: DragEventHandler<HTMLDivElement> = e => {
		e.preventDefault();
	};

	const dragLeave: DragEventHandler<HTMLDivElement> = e => {
		e.preventDefault();
		setIsDragging(false);
	};

	const fileDrop: DragEventHandler<HTMLDivElement> = e => {
		e.preventDefault();
		setIsDragging(false);
		const files = e.dataTransfer.files;
		setFiles(prevFiles => [ ...prevFiles, ...Array.from(files!) ]);
	};

	const handleFileInputChange = (e: ChangeEvent<HTMLInputElement>) => {
		const files = e.target.files;
		setFiles(prevFiles => [ ...prevFiles, ...Array.from(files!) ]);
	};

	const handleBrowseFiles = () => {
		if (fileInput && fileInput.current) fileInput.current.click();
	};

	return (
		<div>
			<div
				className={`upload-zone ${isDragging && 'is-dragging'}`}
				onDragOver={dragOver}
				onDragEnter={dragEnter}
				onDragLeave={dragLeave}
				onDrop={fileDrop}
			>
				<img src="/images/cloud-computing.png" alt="cloud computing" width="60px" />
				<h3>
					Drag files here or{' '}
					<button className="browse-button" onClick={handleBrowseFiles}>
						browse
					</button>
				</h3>
			</div>
			<input
				ref={fileInput}
				type="file"
				name="file"
				accept="*"
				style={{ display: 'none' }}
				onChange={e => handleFileInputChange(e)}
				multiple
			/>
		</div>
	);
};
