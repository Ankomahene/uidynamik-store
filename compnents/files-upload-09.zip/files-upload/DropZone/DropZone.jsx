import React, { useRef, useState } from 'react';
import './DropZone.css';

export const DropZone = ({ setFiles }) => {
	const [ isDragging, setIsDragging ] = useState(false);
	const fileInput = useRef(null);

	const dragOver = e => {
		e.preventDefault();
		setIsDragging(true);
	};

	const dragEnter = e => {
		e.preventDefault();
	};

	const dragLeave = e => {
		e.preventDefault();
		setIsDragging(false);
	};

	const fileDrop = e => {
		e.preventDefault();
		setIsDragging(false);
		const files = e.dataTransfer.files;
		setFiles(prevFiles => [ ...prevFiles, ...Array.from(files) ]);
	};

	const handleFileInputChange = e => {
		const files = e.target.files;
		setFiles(prevFiles => [ ...prevFiles, ...Array.from(files) ]);
	};

	const handleBrowseFiles = () => {
		if (fileInput && fileInput.current) fileInput.current.click();
	};

	return (
		<div>
			<div
				className={`upload-zone ${isDragging && 'is-dragging'}`}
				onDragOver={dragOver}
				onDragEnter={dragEnter}
				onDragLeave={dragLeave}
				onDrop={fileDrop}
			>
				<img src="/images/cloud-computing.png" alt="cloud computing" width="60px" />
				<h3>
					Drag files here or{' '}
					<button className="browse-button" onClick={handleBrowseFiles}>
						browse
					</button>
				</h3>
			</div>
			<input
				ref={fileInput}
				type="file"
				name="file"
				accept="*"
				style={{ display: 'none' }}
				onChange={e => handleFileInputChange(e)}
				multiple
			/>
		</div>
	);
};
