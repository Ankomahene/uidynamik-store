import { useState } from 'react';
import { DropZone } from './DropZone/DropZone';
import './FilesUpload.css';
import { ProgressBar } from './Progress/Progress';

export const FilesUpload = () => {
	const [ progressValue /*setProgressValue */ ] = useState(0);
	const [ files, setFiles ] = useState([]);

	const handleUploadAll = () => {
		// handle your upload all action here
	};

	const handleClearAll = () => {
		setFiles([]);
	};

	return (
		<div className="files-upload-card">
			<div className="title-section">
				<div className="files-upload-title">Upload files</div>
				<button className="close-button"> x </button>
			</div>
			<DropZone setFiles={setFiles} />
			<div className="progress-section">
				{files.map(file => <ProgressBar key={file.name} progressValue={progressValue} file={file} />)}
			</div>
			{files.length !== 0 && (
				<div className="base-button-wrapper">
					<button className="clear-button" onClick={handleClearAll}>
						Clear
					</button>
					<button className="upload-all-button" onClick={handleUploadAll}>
						Upload all
					</button>
				</div>
			)}
		</div>
	);
};
