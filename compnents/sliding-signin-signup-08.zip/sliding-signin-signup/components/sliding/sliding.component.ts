import { Component } from '@angular/core';

@Component({
	selector: 'app-sliding',
	templateUrl: './sliding.component.html',
	styleUrls: [ './sliding.component.scss' ]
})
export class SlidingLoginSignupComponent {
	isRightPanelActive = false;

	togglePanel(): void {
		this.isRightPanelActive = !this.isRightPanelActive;
	}
}
