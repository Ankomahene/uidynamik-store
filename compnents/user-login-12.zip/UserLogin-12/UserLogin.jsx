import React from "react";
import "./UserLogin.scss";
import userIcon from "./icons/user.svg";
import lockIcon from "./icons/lock.svg";
import facebookIcon from "./icons/facebook.svg";
import behanceIcon from "./icons/behance.svg";
import googlePlusIcon from "./icons/google-plus.svg";
import twitterIcon from "./icons/twitter.svg";

export const UserLogin = () => {
  return (
    <div className="login-card">
      <section className="main">
        <a href="#signUp" className="signup-link">
          Sign Up
        </a>
        <form className="form">
          <div className="form-item">
            <span className="form-icon">
              <img src={userIcon} alt="user" />
            </span>
            <input type="text" placeholder="Username" />
          </div>
          <div className="form-item">
            <span className="form-icon">
              <img src={lockIcon} alt="user" />
            </span>
            <input type="password" placeholder="Password" />
          </div>
          <button type="submit" className="submitBtn">
            Login
          </button>
        </form>
        <a href="#fp">Forgot Password?</a>
      </section>
      <footer className="footer">
        <div className="footer-title">Sign in with</div>
        <div className="icons">
          <a href="#facebook" className="footer-icon">
            <img src={facebookIcon} alt="facebook" />
          </a>
          <a href="#google-plus" className="footer-icon">
            <img src={googlePlusIcon} alt="google plus" />
          </a>
          <a href="#twitter" className="footer-icon">
            <img src={twitterIcon} alt="twitter" />
          </a>
          <a href="#behance" className="footer-icon">
            <img src={behanceIcon} alt="behance" />
          </a>
        </div>
      </footer>
    </div>
  );
};
