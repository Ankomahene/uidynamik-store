Design Inspiration
https://www.uidesigndaily.com/posts/photoshop-login-authentication-day-382