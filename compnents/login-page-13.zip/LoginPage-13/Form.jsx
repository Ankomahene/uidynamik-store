import React from "react";
import "./Form.css";
// import "./Form.scss";

export const Form = () => {
  return (
    <div className="form-13">
      <form>
        <input className="form-item" type="email" placeholder="Email Address" />
        <input className="form-item" type="password" placeholder="Password" />
        <div className="form-item secondary-actions">
          <div>
            <input type="checkbox" className="checkbox" checked />
            <label>Keep me signed in</label>
          </div>

          <a href="member#">already and Member?</a>
        </div>
        <input type="submit" />
      </form>
    </div>
  );
};
