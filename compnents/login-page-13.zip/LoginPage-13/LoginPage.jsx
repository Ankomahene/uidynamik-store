import React from "react";
import "./LoginPage.css";
// import "./LoginPage.scss";
import loginVector from "./icons/login.svg";
import { Form } from "./Form";

export const LoginPage = () => {
  return (
    <div className="login-page-13">
      <div className="col col-1">
        <div>
          <img src={loginVector} alt="login vector" />
        </div>
        <div>Nice to see you again</div>
        <div className="welcome-text">Welcome Back</div>
      </div>
      <div className="col col-2">
        <div className="title">Login Account</div>
        <div className="description">
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eaque
          quaerat soluta alias fugit atque veniam.
        </div>
        <Form />
      </div>
    </div>
  );
};
