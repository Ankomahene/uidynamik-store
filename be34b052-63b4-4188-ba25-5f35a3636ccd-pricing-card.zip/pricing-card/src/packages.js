export const packages = [
	{
		title: 'Starter',
		price: 9.99,
		offers: [
			'Unlimited public and private repositories',
			'Unlimited collaborators',
			'2,000 Actions minutes/month',
			'500MB Storage Space',
			'Community Support'
		]
	},
	{
		title: 'Professional',
		price: 19.99,
		offers: [
			'Everything in Starter',
			'Required reviewers',
			'3,000 Actions minutes/month',
			'2GB Storage Space',
			'Code owners'
		]
	},
	{
		title: 'Enterprise',
		price: 39.99,
		offers: [
			'Everything in Professional',
			'SAML single sign-on',
			'50,000 Actions minutes/month',
			'50GB Storage Space',
			'Advanced auditing'
		]
	}
];
