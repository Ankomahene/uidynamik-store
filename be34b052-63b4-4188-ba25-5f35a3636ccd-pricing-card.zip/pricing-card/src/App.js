import React from 'react';
import { packages } from './packages';
import PricingCard from './components/PricingCard';
import './App.css';

/*	README: TO get the actual component open the components directory
	You can copy component js and css file into your project
	Props are passed to component to make it dynamic: you can pass your own props
	Check card options in the packages.js file
*/
const App = () => {
	return (
		<div className="App">
			{packages.map((pricePackage, index) => <PricingCard key={index} cardOptions={pricePackage} />)}
		</div>
	);
};

export default App;
