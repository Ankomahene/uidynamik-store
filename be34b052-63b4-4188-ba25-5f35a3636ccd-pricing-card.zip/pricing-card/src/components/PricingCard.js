import React from 'react';
import './PricingCard.css';
import { CheckIcon } from '../icon';

const PricingCard = ({ cardOptions: { title, price, offers } }) => {
	return (
		<div className="card">
			<div className="card-image">
				<img src="pc.png" width="50%" alt="cardImg" />
			</div>
			<h4 className="card-title">
				{/* props used here*/} {title}
			</h4>
			<div className="card-price">
				<div className="card-price-amount">
					{/* props used here*/} ${price}
				</div>
				<div className="card-price-duration">PER MONTH</div>
			</div>
			<div className="card-offers">
				{/* props used here*/}
				{offers.map(offer => {
					return (
						<div className="card-offer" key={offer}>
							<div className="card-offer-icon">
								<CheckIcon />
							</div>
							<div>{offer}</div>
						</div>
					);
				})}
			</div>
			<div className="card-button">
				<button>START</button>
			</div>
		</div>
	);
};

export default PricingCard;
