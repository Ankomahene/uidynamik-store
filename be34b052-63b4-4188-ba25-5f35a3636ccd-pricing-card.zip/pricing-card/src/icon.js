import React from 'react';

export const CheckIcon = () => {
	return (
		<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="#00ff00" viewBox="0 0 20 20">
			<title>checkmark</title>
			<path d="M0 11l2-2 5 5 11-11 2 2-13 13z" />
		</svg>
	);
};
