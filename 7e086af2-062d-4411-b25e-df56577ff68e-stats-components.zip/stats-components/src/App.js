import React from 'react';
import './App.css';
import Stat from './components/Stat';

function App() {
	return (
		<div className="App">
			<div className="container">
				<div>
					{/* You just need only one of these cards to pass the props for your list of items */}
					<Stat bgColor="624CAB" icon="comment" stat="786" description="Total Comments" />
					{/* ------------------------------------------------------------------------- */}
					<Stat bgColor="758ecd" icon="like" stat="12,343" description="Total Likes" />
				</div>
				<div>
					<Stat bgColor="7189ff" icon="view" stat={(12, 349)} description="Total Views" />
					<Stat bgColor="8472c0" icon="rating" stat={(12, 349)} description="Total Views" />
				</div>
			</div>
		</div>
	);
}

export default App;
