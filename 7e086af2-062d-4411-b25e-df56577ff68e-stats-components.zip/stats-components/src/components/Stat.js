import React from 'react';
import './Stat.css';

const Stat = ({ bgColor, icon, stat, description }) => {
	return (
		<div className="card" style={{ backgroundColor: `#${bgColor}` }}>
			<div className="icon-stat">
				<div className="icon">
					{' '}
					<img src={`./icons/${icon}.svg`} alt="" />
				</div>
				<h1 className="stats">{stat}</h1>
			</div>

			<div className="description">{description}</div>
		</div>
	);
};

export default Stat;
