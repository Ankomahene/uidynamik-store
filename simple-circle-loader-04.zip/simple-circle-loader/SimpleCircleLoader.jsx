import React from 'react';
import './SimpleCircleLoader.css';

const SimpleCircleLoader = () => {
	return <div className="simple-circle-loader" />;
};

export default SimpleCircleLoader;
