import React from 'react';
import './App.css';
import SwiperCore, { Navigation, Pagination } from 'swiper';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/swiper.scss';
import 'swiper/components/navigation/navigation.scss';
import 'swiper/components/pagination/pagination.scss';

SwiperCore.use([Navigation, Pagination]);

function App() {
	return (
		<div className="App">
			<h1>TOUCH SLIDER</h1>
			<Swiper
				spaceBetween={30}
				slidesPerView={3}
				navigation
				pagination={{ clickable: true }}
				onSlideChange={() => console.log('slide change')}
				onSwiper={swiper => console.log(swiper)}
				className="swiper-container"
			>
				{users.map(user => (
					<SwiperSlide key={user.id} className="slide">
						<div className="slide-content">
							<div className="user-image">
								<img className="user-photo" src="/user.png" alt="user" />
							</div>
							<h5>{user.username}</h5>
							<p className="user-testimonial">
								" <i>{user.testimonial}</i>"
							</p>
						</div>
					</SwiperSlide>
				))}
			</Swiper>
		</div>
	);
}

// Replace this data with yours
const users = [
	{
		id: 1,
		username: 'Shadrack',
		testimonial: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit.'
	},
	{
		id: 2,
		username: 'Dennis',
		testimonial: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit.'
	},
	{
		id: 3,
		username: 'Alexander',
		testimonial: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit.'
	},
	{
		id: 4,
		username: 'Isaac',
		testimonial: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit.'
	},
	{
		id: 5,
		username: 'John',
		testimonial: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit.'
	},
	{
		id: 6,
		username: 'Ali',
		testimonial: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit.'
	}
];

export default App;
