import React from 'react';
import './App.scss';
import Icon from './Icon';

function App() {
	const iconSize = '2.5em';

	return (
		<div className="App">
			<div className="card">
				<div className="icon">
					<Icon fill="#6707C0" size={iconSize} />
				</div>
				<div className="title">
					<h4>Get the latest updates right into your inbox!</h4>
				</div>
				<div className="content">
					<p>Join 6k+ subscribers!</p>
					<div className="form">
						<input type="email" name="" id="" placeholder="Enter your email" />
						<button>Subscribe</button>
					</div>
				</div>
			</div>
		</div>
	);
}

export default App;
